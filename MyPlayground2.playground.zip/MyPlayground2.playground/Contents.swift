//1. 반환값과 매개함수가 둘다 없는함수
func printhello () {
    print("안녕하세요")
}
//2. 매개변수는 없지만 반환값은 있는 함수
func hello () -> String {
    let returnvalue = "안녕하세요"
    return returnvalue
}
//3. 매개변수는 있으나 반환값이 없는 함수
func printhellowithname (name: String) {
    print("\(name) 님 안녕하세요")
}
//4. 매개변수와 반환값이 모두 있는 함수
func sayhellowithname (name: String) -> String {
    let returnvalue = "\(name)님 안녕하세요"
    return returnvalue
}


