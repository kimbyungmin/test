for i in 1...5{
    for j in 1...9{
        if (j == 3){
            break
        }
    print ("\(i) X \(j) = \(i * j)")
    }
    }
    
아아
test
check
